import scrapy
import sqlite3

from scrapy.pipelines.images import ImagesPipeline

class AuktionImagePipeline(ImagesPipeline):
    def get_media_requests(self, item, info):       
        count = 0
        if not item['images'] == 'None':
            for img_url in item['images']:
                count += 1
                yield scrapy.Request(img_url, meta={'image_name': item["id"],'count': count})

    def file_path(self, request, response=None, info=None):
        return f"{request.meta['image_name']}'_{request.meta['count']}'.jpg" 

class AuktionPipeline(object):

    def __init__(self,new):

        self.create_connection()
        self.create_table(new)
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(new=crawler.spider.new)


    def create_connection(self):

        self.conn = sqlite3.Connection('auktion.db')
        self.curr = self.conn.cursor()
    
    def create_table(self,new):

        if new == "yes":

            self.curr.execute("drop table if exists auktion_table")
            self.curr.execute("CREATE TABLE auktion_table( id text, date text,auction_number text,lot_number text, description text, catlog_number text, condition_of_product text, est text,images text ,sold_for text,product_id text, parent text, child text)")

    def process_item(self, item, spider):

        self.store_db(item)

        return item

    def store_db(self,item):

        images = ",".join(item["images"])

        self.curr.execute(f"insert into auktion_table values ('{item['id']}','{item['date']}','{item['auction_number']}','{item['lot_number']}','{item['description']}','{item['catlog_number']}','{item['condition_of_product']}','{item['est']}','{images}','{item['sold_for']}','{item['product_id']}','{item['parent']}','{item['child']}')")

        self.conn.commit()