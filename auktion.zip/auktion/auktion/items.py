# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class AuktionItem(scrapy.Item):

    auction_number = scrapy.Field()
    lot_number = scrapy.Field()
    images = scrapy.Field()
    description = scrapy.Field()
    catlog_number = scrapy.Field()
    condition_of_product = scrapy.Field()
    est = scrapy.Field()
    sold_for = scrapy.Field()

    id = scrapy.Field()
    product_id = scrapy.Field()
    date = scrapy.Field()
    parent = scrapy.Field()
    child = scrapy.Field()

    pass
