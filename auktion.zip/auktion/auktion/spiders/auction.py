from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import AuktionItem
import re

import csv
import datetime


class ActionSpider(CrawlSpider):

    product_id = 0
    id = 0

    name = "auction"

    date_time = None

    catagory = []

    img_link = "https://auktion.reinhardfischerauktionen.de"

    clear_img = "https://auktion.reinhardfischerauktionen.de/photos/"

    image_code = ["**","*","(*)","gestempelt.svg","VB","briefstueck.svg","brief.svg"]

    #start_urls = ['https://auktion.reinhardfischerauktionen.de/de/search/archive/results?s%5BauctionNrFrom%5D=&s%5BauctionNrTo%5D=&s%5BcategoryId1%5D=20&s%5BcategoryId2%5D=23&s%5BcategoryId3%5D=30']

    main_link = "https://auktion.reinhardfischerauktionen.de/de/search/archive/results?s%5BauctionNrFrom%5D=&s%5BauctionNrTo%5D=&s%5BcategoryId1%5D=20&s%5BcategoryId2%5D=swap_parent&s%5BcategoryId3%5D=swap_child"

    def __init__(self, new, *args, **kwargs):                    
        super(ActionSpider, self).__init__(*args, **kwargs) 

        self.new = new

        if new == "no":
            id_file = open("systemid.txt","r")
            self.id = id_file.readline()
            self.id = self.id.strip("\n")
            self.id = int(self.id)
            id_file.close()

        # id to control scrape product using product id > id in side id.txt
        id_file = open("lastID.txt","r")
        self.product_id = id_file.readline()
        self.product_id = self.product_id.strip("\n")
        self.product_id = int(self.product_id)
        id_file.close()

        self.date_time = datetime.datetime.now()

        self.links = [] 
        

        with open('input.csv') as csv_file:
            csv_reader = csv.DictReader(csv_file)

            for row in csv_reader:

                temp_cat = []
                
                parent = row["maincat"]
                temp_cat.append(parent)

                child = row["subcat"]
                temp_cat.append(child)

                temp = self.main_link
                temp = temp.replace("swap_parent",str(parent))
                temp = temp.replace("swap_child",str(child))

                self.catagory.append(temp_cat)
                self.links.append(temp)

    def start_requests(self):   

        for url in self.links:                                    
            yield Request(url = url,meta={"page_no":2,"link":url} ,callback = self.product_page)        

    
    def product_page(self,response):

        if response.css(".lots-list-row"):
        
            for data in response.css(".lots-list-row"):

                product = AuktionItem()

                idd = data.css(".lot-num.lot-label-archive a::attr(href)").extract_first().split("lot/")[1]

                if int(idd) > self.product_id:

                    product["product_id"] = int(idd)

                    for parent_child  in self.catagory:
                    
                        if str(parent_child[0]) in response.url and str(parent_child[1]) in response.url:
                            product["parent"] = str(parent_child[0])
                            product["child"] = str(parent_child[1])

                    product["date"] = self.date_time

                    product["id"] = self.id
                    id_file = open("systemid.txt","w")
                    id_file.write(str(self.id))
                    id_file.close()

                    self.id += 1
        
                    auction_lotnumber = data.css(".lot-num.lot-label-archive a::text").extract_first()  

                    product["auction_number"] = auction_lotnumber.split("|")[0].replace("Auktion","")
                    product["lot_number"] = auction_lotnumber.split("|")[1].replace("Los","")

                    product["description"] = data.css(".lot-description-wrapper > div:nth-child(2)::text").extract_first()
                    product["description"] = product["description"].strip("\n")
                    product["description"] = product["description"].strip()
                    product["description"] = product["description"].replace("'","")

                    product["images"] = []

                    imgg = data.css(".lot-image-wrapper img::attr(src)").extract_first()

                    if imgg:
                        imgg = imgg.split("lot_list_thumb/")[1]
                        imgg = self.clear_img + imgg

                        product["images"].append(imgg)
                    

                    try:
                        product["images"].append(self.img_link + data.css(".mfp-image::attr(href)").extract_first())
                    except:
                        pass
                    

                    try:
                        start_price = data.css(".lots-list-price.lots-list-start-price::text").extract_first().strip("\n ")
                        product["est"] = data.css(".lots-list-prices-price::text").extract()
                        product["est"] = "".join(product["est"])
                        product["est"] = start_price + product["est"].strip()[0]

                    except:
                        product["est"] = 'None'

                    
                    try:
                        start_price = data.css(".lots-list-price.lots-list-end-price::text").extract_first().strip("\n ")
                        product["sold_for"] = data.css(".lots-list-prices-price::text").extract()
                        product["sold_for"] = "".join(product["sold_for"])
                        product["sold_for"] = start_price + product["sold_for"].strip()[0]

                    except:
                        product["sold_for"] = 'None'



                    product["catlog_number"] = data.css(".lot-icons-wrapper div:first-child::text").extract_first().strip("\n ")

                    condition_of_product = data.css(".lot-icons-wrapper img::attr(src)").extract()

                    if condition_of_product:

                        product["condition_of_product"] = 0
                        
                        for condition in condition_of_product:
                            for index,code in enumerate(self.image_code):
                                if code in condition:
                                    product["condition_of_product"] += index

                    else:

                        temp_catlog_number = product["catlog_number"].split(" ")[0]

                        product["condition_of_product"] = 0

                        try:
                        
                            condition_of_product = product["catlog_number"].split(" ")[1]

                            product["catlog_number"] = temp_catlog_number

                            for index,code in enumerate(self.image_code):
                                if code in condition_of_product:
                                    product["condition_of_product"] += index
                        except:
                            product["catlog_number"] = 'None'
                            product["condition_of_product"] = 'None'


                    yield product
            
            next_page = response.meta['link'].split("results")[0]
            next_page = next_page + f"results/{response.meta['page_no']}" + response.meta['link'].split("results")[1]

            yield Request(url = next_page,meta={"page_no":response.meta['page_no'] + 1,"link":response.meta['link']} ,callback=self.product_page)
        
        else:

                return
